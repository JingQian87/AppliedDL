ADL Project

Jing Qian (jq2282)

The video link is: https://youtu.be/VbFY0pNq9ok

This fold consists of following:
1. End to end notebook: project_jq2282.ipynb
2. Slides used in presentation: ProjectPresent.pdf
3. Predicted heatmaps
* Saved model is too large to submit, the saving and loading code is implemented in the notebook.